#pragma once
// Set to 1 after wiring and installing "hd44780" by Bill Perry in Library Manager.
// Kept off while the new LCD is not connected, so existing sensor firmware still builds.
#ifndef CATCHLAB_LCD_ENABLED
#define CATCHLAB_LCD_ENABLED 0
#endif
constexpr int LcdSdaPin = 8;
constexpr int LcdSclPin = 9;
